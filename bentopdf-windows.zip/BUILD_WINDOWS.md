# Build BentoPDF jadi aplikasi Windows (.exe)

Tidak ada satu pun kode di `src/js`, `src/css`, atau HTML yang diubah.
Yang ditambahkan hanya:

- `electron/main.cjs` — window native yang memuat hasil build (`dist/index.html`)
- `vite.config.ts` → tambah `base: './'` (wajib, supaya asset ketemu saat dibuka lewat `file://`, bukan server)
- `package.json` → tambah `main`, dua script baru, dan config `build` untuk electron-builder

## Cara build (harus dijalankan di komputer Anda sendiri — perlu koneksi internet untuk `npm install`)

```bash
npm install
npm run electron:build:win
```

Hasilnya muncul di folder `release/`:
- `BentoPDF Setup x.x.x.exe` — installer (NSIS), ada shortcut desktop & uninstaller
- `BentoPDF x.x.x.exe` — versi portable, tinggal jalankan tanpa install

Bisa build di Windows, macOS, atau Linux — electron-builder bisa cross-compile ke Windows dari OS lain asalkan `npm install` berhasil mengunduh dependency-nya.

## Coba dulu sebelum build final (opsional)

```bash
npm run electron:dev
```
Ini akan build lalu langsung buka app di window Electron, tanpa proses packaging.

## Perubahan untuk 100% offline

Semua yang tadinya fetch dari CDN sudah diganti jadi bundled lokal, kecuali satu hal yang memang tidak bisa saya download di environment saya (lihat poin OCR):

| Sebelumnya (butuh internet) | Sekarang |
|---|---|
| `simpleanalyticscdn.com` (analytics) | Dihapus |
| Google Fonts (DM Sans, Dancing Script, dst) | `@fontsource/*` — di-bundle Vite lokal |
| CSS Cropper dari cdnjs | `import 'cropperjs/dist/cropper.css'` — lokal |
| Badge GDPR/CCPA/HIPAA dari `mkt-cf.pdffiller.com` | Diganti icon lucide lokal |
| Icon lucide dari `unpkg.com` (5 halaman: about/contact/faq/privacy/terms) | Package npm `lucide` lokal, lewat `src/js/static-page.ts` |
| Viewer "PDF Editor" dari `snippet.embedpdf.com` | Package npm `@embedpdf/snippet`, wasm PDFium lokal, font/stamp CDN bawaannya dimatikan |
| **OCR PDF** — `tesseract.js` fetch worker/core dari jsdelivr + data bahasa dari `tessdata.projectnaptha.com` | Worker & core sudah lokal otomatis (lewat `scripts/copy-offline-assets.mjs`, jalan otomatis sebelum `npm run build`). **Data bahasa (`.traineddata.gz`) harus Anda taruh manual** di `public/tessdata/` — panduan lengkap di `public/tessdata/README.md`. Saya tidak bisa download file ini karena environment saya tidak ada akses internet. |

## Fitur ganti tema

Ada tombol bulat kecil kanan-atas (icon matahari/bulan) di semua halaman — ganti antara tema gelap (default, seperti sebelumnya) dan tema terang ala-iLovePDF (putih + aksen merah). Pilihan tersimpan otomatis (localStorage), tidak perlu setting ulang tiap buka app. Nama brand tetap "BentoPDF" di kedua tema — tidak pakai nama/logo iLovePDF.

## Catatan lain

- App tetap 100% client-side: tidak ada perubahan pada cara `pdf-lib`/`pdfjs`/`jspdf` memproses file — semua logic asli di `src/js/logic/*` dipakai apa adanya.
- Belum ada file ikon `.ico` custom (build ini tidak punya tool untuk convert SVG→ICO secara offline). Kalau mau ikon khusus: buat `build-resources/icon.ico` (256×256, multi-size), lalu tambahkan `"icon": "build-resources/icon.ico"` di bagian `build.win` pada `package.json`.
- **Belum sempat saya verifikasi dengan `npm run build` sungguhan** (environment saya tidak bisa `npm install` — tidak ada akses internet). Nama-nama package/asset (`@embedpdf/*`, `@fontsource/*`, path `tesseract.js/dist/worker.min.js?url`, dll) saya isi berdasarkan dokumentasi resmi masing-masing, tapi kalau versi yang ter-install nanti berbeda dan ada error saat `npm install` atau `npm run build`, kemungkinan besar cuma butuh penyesuaian versi/nama file kecil — tinggal kirim pesan error-nya ke saya.
