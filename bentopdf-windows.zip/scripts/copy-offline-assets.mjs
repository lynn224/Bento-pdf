// Menyalin node_modules/tesseract.js-core -> public/tesseract-core supaya
// Tesseract.js membaca file core (wasm) dari app itu sendiri, bukan dari CDN
// jsdelivr default-nya. Dijalankan otomatis sebelum "npm run build" (lihat
// package.json -> "prebuild").
import { existsSync, mkdirSync, cpSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const src = path.join(root, 'node_modules', 'tesseract.js-core');
const dest = path.join(root, 'public', 'tesseract-core');

if (!existsSync(src)) {
    console.warn(
        '[copy-offline-assets] node_modules/tesseract.js-core tidak ditemukan.\n' +
        'Jalankan "npm install" dulu. Fitur OCR PDF tidak akan berfungsi offline tanpa folder ini.'
    );
    process.exit(0);
}

mkdirSync(dest, { recursive: true });
cpSync(src, dest, { recursive: true });
console.log('[copy-offline-assets] tesseract.js-core -> public/tesseract-core OK');
