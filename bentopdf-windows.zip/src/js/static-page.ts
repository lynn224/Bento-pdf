import { icons, createIcons } from 'lucide';
import { initTheme } from './theme.js';

createIcons({ icons });
initTheme();
