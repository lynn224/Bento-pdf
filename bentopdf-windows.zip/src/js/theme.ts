import { icons, createIcons } from 'lucide';

const THEME_KEY = 'bentopdf-theme';
type Theme = 'dark' | 'light';

function getSavedTheme(): Theme {
    try {
        const saved = localStorage.getItem(THEME_KEY);
        return saved === 'light' ? 'light' : 'dark';
    } catch {
        return 'dark';
    }
}

function applyTheme(theme: Theme) {
    document.documentElement.setAttribute('data-theme', theme);
    try {
        localStorage.setItem(THEME_KEY, theme);
    } catch {
        // localStorage tidak tersedia (mis. private mode) — tema tetap jalan, cuma tidak diingat
    }

    const btn = document.getElementById('theme-toggle-btn');
    if (btn) {
        btn.innerHTML = theme === 'dark'
            ? '<i data-lucide="sun" class="w-5 h-5"></i>'
            : '<i data-lucide="moon" class="w-5 h-5"></i>';
        btn.setAttribute('title', theme === 'dark' ? 'Ganti ke tema terang' : 'Ganti ke tema gelap');
        createIcons({ icons });
    }
}

/**
 * Memasang tombol ganti tema (mengambang, kanan-atas) di semua halaman,
 * tanpa perlu menyentuh markup nav yang berbeda-beda tiap file HTML.
 */
export function initTheme() {
    const current = getSavedTheme();
    document.documentElement.setAttribute('data-theme', current);

    if (document.getElementById('theme-toggle-btn')) return;

    const btn = document.createElement('button');
    btn.id = 'theme-toggle-btn';
    btn.type = 'button';
    btn.setAttribute('aria-label', 'Ganti tema tampilan');
    btn.className = 'fixed top-3 right-3 z-50 w-10 h-10 rounded-full flex items-center justify-center shadow-lg transition-colors';
    document.body.appendChild(btn);

    applyTheme(current);

    btn.addEventListener('click', () => {
        const now = (document.documentElement.getAttribute('data-theme') as Theme) || 'dark';
        applyTheme(now === 'dark' ? 'light' : 'dark');
    });
}
