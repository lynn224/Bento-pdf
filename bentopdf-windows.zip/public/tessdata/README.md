# Data bahasa OCR (wajib diisi manual)

Tool "OCR PDF" butuh file `.traineddata.gz` per bahasa. Ini file model bahasa
(beberapa MB per bahasa) — saya (Claude) tidak punya akses internet di
environment saat mengerjakan proyek ini, jadi file-nya tidak bisa saya
download otomatis. Ini satu-satunya bagian yang perlu diisi manual supaya
app 100% offline.

## Cara mengisi

1. Buka https://github.com/naptha/tessdata_fast (versi "fast", ukuran lebih kecil — cukup akurat untuk kebanyakan dokumen) atau https://github.com/naptha/tessdata (versi "best", lebih akurat tapi lebih besar).
2. Download file bahasa yang dibutuhkan, contoh:
   - `eng.traineddata.gz` (Inggris)
   - `ind.traineddata.gz` (Indonesia)
3. Taruh file-file itu langsung di folder ini (`public/tessdata/`), sejajar dengan README ini. Jangan di dalam subfolder.
4. Build ulang (`npm run build`).

Kode sudah otomatis mengarah ke folder ini (`langPath: './tessdata'` di
`src/js/logic/ocr-pdf.ts`) — begitu file-nya ada di sini, tool OCR jalan
tanpa internet. Kalau user OCR pakai bahasa yang file-nya belum ada di sini,
Tesseract akan gagal fetch (karena tidak ada internet) — jadi sesuaikan daftar
bahasa yang ditawarkan di UI dengan file yang benar-benar Anda taruh di sini
kalau distribusi app harus tetap ringan.
